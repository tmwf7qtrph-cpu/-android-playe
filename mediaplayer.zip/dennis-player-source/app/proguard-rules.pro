# Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep data classes used for JSON parsing (org.json reflection-free, but keep names stable for debugging)
-keep class com.dennis.player.subtitles.SubtitleResult { *; }
-keep class com.dennis.player.subtitles.SubtitleAddon { *; }

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**

-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
