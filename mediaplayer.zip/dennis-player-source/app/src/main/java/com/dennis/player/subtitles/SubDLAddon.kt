package com.dennis.player.subtitles

import com.dennis.player.settings.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Real integration with the SubDL REST API (api.subdl.com).
 *
 * Requires a free API key from https://subdl.com/api — enter it in
 * Settings > OpenSubtitles API Key field (the generic API key field is reused
 * for simplicity; you can split it later if you use both providers).
 * Without a key, search() returns an empty list.
 */
class SubDLAddon(
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override val id: String = "subdl"
    override val label: String = "SubDL"

    override val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    override val configurationHint: String
        get() = "Voer je SubDL API-sleutel in bij Instellingen"

    private val apiKey: String
        get() = PlayerPreferences.openSubtitlesApiKey

    companion object {
        private const val BASE = "https://api.subdl.com/api/v1/subtitles"
        private const val UA = "DennisRemuxPlayer/1.0"
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext emptyList()

            val url = buildString {
                append(BASE)
                append("?api_key=").append(URLEncoder.encode(apiKey, "UTF-8"))
                append("&languages=").append(URLEncoder.encode(languageCode, "UTF-8"))
                if (!imdbId.isNullOrBlank()) {
                    append("&imdb_id=").append(URLEncoder.encode(imdbId, "UTF-8"))
                } else {
                    append("&query=").append(URLEncoder.encode(query, "UTF-8"))
                }
            }

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val body = response.body?.string() ?: return@withContext emptyList()
                    parse(body)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun parse(body: String): List<SubtitleResult> {
        val root = JSONObject(body)
        val data = root.optJSONArray("subtitles") ?: root.optJSONArray("data") ?: return emptyList()
        val results = mutableListOf<SubtitleResult>()
        for (i in 0 until data.length()) {
            val entry = data.getJSONObject(i)
            val url = entry.optString("url", entry.optString("download_url", ""))
            if (url.isBlank()) continue
            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = entry.optString("language", "und"),
                    releaseTitle = entry.optString("release_name", entry.optString("filename", "SubDL subtitle")),
                    format = entry.optString("format", "srt").uppercase(),
                    downloadUrl = url,
                    quality = entry.optString("quality", ""),
                    isHearingImpaired = entry.optBoolean("hearing_impaired", false)
                )
            )
        }
        return results
    }
}
