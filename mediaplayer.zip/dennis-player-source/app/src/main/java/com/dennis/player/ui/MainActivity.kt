package com.dennis.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.dennis.player.R
import com.dennis.player.player.PlayerActivity
import com.dennis.player.settings.SettingsActivity

/**
 * Standalone launcher screen. Lets the user open a local/network file
 * directly, jump to the playlist, or open Settings. When launched via an
 * external ACTION_VIEW intent (e.g. from Stremio), playback is handled
 * directly by PlayerActivity instead — this screen is only shown when the
 * app is opened from the home screen / leanback launcher.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Toolbar>(R.id.toolbar)?.let { setSupportActionBar(it) }

        findViewById<android.widget.Button>(R.id.buttonOpenFile).setOnClickListener {
            openDocumentPicker()
        }
        findViewById<android.widget.Button>(R.id.buttonPlaylist).setOnClickListener {
            startActivity(Intent(this, PlaylistActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.buttonSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun openDocumentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, REQUEST_OPEN_FILE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OPEN_FILE && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            startActivity(
                Intent(this, PlayerActivity::class.java).apply {
                    action = Intent.ACTION_VIEW
                    setDataAndType(uri, "video/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        }
    }

    companion object {
        private const val REQUEST_OPEN_FILE = 1001
    }
}
