package com.dennis.player

import android.app.Application
import com.dennis.player.settings.PlayerPreferences

/**
 * Application entry point. Initializes the preference store used across the
 * player, settings and subtitle screens.
 */
class DennisPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        PlayerPreferences.init(this)
    }
}
