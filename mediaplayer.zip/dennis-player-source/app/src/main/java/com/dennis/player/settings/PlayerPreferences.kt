package com.dennis.player.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.dennis.player.video.VideoZoomMode

/**
 * Centralized, typed access to all persisted player settings. Backed by a
 * single SharedPreferences file so every screen (Player, Settings, Subtitle
 * pickers) reads/writes the same source of truth.
 */
object PlayerPreferences {

    private const val PREFS_NAME = "dennis_player_prefs"

    private const val KEY_HW_DECODING = "hw_decoding_enabled"
    private const val KEY_TUNNELED_PLAYBACK = "tunneled_playback_enabled"
    private const val KEY_AUTO_PLAY = "auto_play_enabled"
    private const val KEY_ZOOM_MODE = "video_zoom_mode"
    private const val KEY_AUDIO_LANGUAGE = "preferred_audio_language"
    private const val KEY_SUBTITLE_LANGUAGE = "preferred_subtitle_language"
    private const val KEY_AUTO_DUTCH_SUBS = "auto_select_dutch_subtitle"
    private const val KEY_ENABLED_ADDONS = "enabled_subtitle_addons"
    private const val KEY_SUB_TEXT_SIZE = "subtitle_text_size_pt"
    private const val KEY_SUB_POSITION = "subtitle_position_percent"
    private const val KEY_SUB_COLOR = "subtitle_color"
    private const val KEY_SUB_OUTLINE = "subtitle_outline_enabled"
    private const val KEY_SUB_SHADOW = "subtitle_shadow_enabled"
    private const val KEY_SUB_BACKGROUND_ALPHA = "subtitle_background_alpha"
    private const val KEY_SUB_BOLD = "subtitle_bold"
    private const val KEY_SUB_ITALIC = "subtitle_italic"
    private const val KEY_SUB_SYNC_OFFSET_MS = "subtitle_sync_offset_ms"
    private const val KEY_SEEK_STEP_SECONDS = "seek_step_seconds"
    private const val KEY_OPENSUBTITLES_API_KEY = "opensubtitles_api_key"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    var hardwareDecodingEnabled: Boolean
        get() = prefs.getBoolean(KEY_HW_DECODING, true)
        set(value) = prefs.edit { putBoolean(KEY_HW_DECODING, value) }

    var tunneledPlaybackEnabled: Boolean
        get() = prefs.getBoolean(KEY_TUNNELED_PLAYBACK, false)
        set(value) = prefs.edit { putBoolean(KEY_TUNNELED_PLAYBACK, value) }

    var autoPlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_PLAY, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_PLAY, value) }

    var zoomMode: VideoZoomMode
        get() = VideoZoomMode.fromKey(prefs.getString(KEY_ZOOM_MODE, VideoZoomMode.FIT.key))
        set(value) = prefs.edit { putString(KEY_ZOOM_MODE, value.key) }

    var preferredAudioLanguage: String
        get() = prefs.getString(KEY_AUDIO_LANGUAGE, "nl") ?: "nl"
        set(value) = prefs.edit { putString(KEY_AUDIO_LANGUAGE, value) }

    var preferredSubtitleLanguage: String
        get() = prefs.getString(KEY_SUBTITLE_LANGUAGE, "nl") ?: "nl"
        set(value) = prefs.edit { putString(KEY_SUBTITLE_LANGUAGE, value) }

    var autoSelectDutchSubtitle: Boolean
        get() = prefs.getBoolean(KEY_AUTO_DUTCH_SUBS, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_DUTCH_SUBS, value) }

    var enabledSubtitleAddons: Set<String>
        get() = prefs.getStringSet(KEY_ENABLED_ADDONS, setOf("opensubtitles")) ?: setOf("opensubtitles")
        set(value) = prefs.edit { putStringSet(KEY_ENABLED_ADDONS, value) }

    var subtitleTextSizePt: Int
        get() = prefs.getInt(KEY_SUB_TEXT_SIZE, 36)
        set(value) = prefs.edit { putInt(KEY_SUB_TEXT_SIZE, value) }

    /** 0 = top of screen, 100 = bottom of screen. */
    var subtitlePositionPercent: Int
        get() = prefs.getInt(KEY_SUB_POSITION, 100)
        set(value) = prefs.edit { putInt(KEY_SUB_POSITION, value.coerceIn(0, 100)) }

    var subtitleColor: Int
        get() = prefs.getInt(KEY_SUB_COLOR, 0xFFFFFFFF.toInt())
        set(value) = prefs.edit { putInt(KEY_SUB_COLOR, value) }

    var subtitleOutlineEnabled: Boolean
        get() = prefs.getBoolean(KEY_SUB_OUTLINE, true)
        set(value) = prefs.edit { putBoolean(KEY_SUB_OUTLINE, value) }

    var subtitleShadowEnabled: Boolean
        get() = prefs.getBoolean(KEY_SUB_SHADOW, true)
        set(value) = prefs.edit { putBoolean(KEY_SUB_SHADOW, value) }

    /** 0..255 alpha applied to the subtitle background box. */
    var subtitleBackgroundAlpha: Int
        get() = prefs.getInt(KEY_SUB_BACKGROUND_ALPHA, 0)
        set(value) = prefs.edit { putInt(KEY_SUB_BACKGROUND_ALPHA, value.coerceIn(0, 255)) }

    var subtitleBold: Boolean
        get() = prefs.getBoolean(KEY_SUB_BOLD, false)
        set(value) = prefs.edit { putBoolean(KEY_SUB_BOLD, value) }

    var subtitleItalic: Boolean
        get() = prefs.getBoolean(KEY_SUB_ITALIC, false)
        set(value) = prefs.edit { putBoolean(KEY_SUB_ITALIC, value) }

    /** Manual subtitle sync offset, in milliseconds. Positive = subtitles appear later. */
    var subtitleSyncOffsetMs: Long
        get() = prefs.getLong(KEY_SUB_SYNC_OFFSET_MS, 0L)
        set(value) = prefs.edit { putLong(KEY_SUB_SYNC_OFFSET_MS, value) }

    /** Fast-forward/rewind step, in seconds. Valid presets: 10, 30, 60, 300. */
    var seekStepSeconds: Int
        get() = prefs.getInt(KEY_SEEK_STEP_SECONDS, 10)
        set(value) = prefs.edit { putInt(KEY_SEEK_STEP_SECONDS, value) }

    /**
     * The OpenSubtitles API requires a free developer API key
     * (https://www.opensubtitles.com/en/consumers). We deliberately do not ship one —
     * enter your own key here (or via Settings) before the OpenSubtitles addon can
     * return results. Without a key, OpenSubtitlesAddon.search() returns an empty list.
     */
    var openSubtitlesApiKey: String
        get() = prefs.getString(KEY_OPENSUBTITLES_API_KEY, "") ?: ""
        set(value) = prefs.edit { putString(KEY_OPENSUBTITLES_API_KEY, value) }
}
