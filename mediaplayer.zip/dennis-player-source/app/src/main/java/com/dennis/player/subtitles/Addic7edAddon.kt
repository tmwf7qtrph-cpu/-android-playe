package com.dennis.player.subtitles

import com.dennis.player.settings.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Real integration with the Addic7ed unofficial REST API
 * (addic7ed.com — community reverse-engineered endpoints).
 *
 * No API key is required for basic search, but Addic7ed rate-limits heavily
 * (one search per ~5 seconds from the same IP). Results may be empty if the
 * rate limit is hit — the app handles this gracefully by returning an empty
 * list instead of crashing.
 */
class Addic7edAddon(
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override val id: String = "addic7ed"
    override val label: String = "Addic7ed"

    companion object {
        private const val SEARCH = "https://www.addic7ed.com/search.php"
        private const val UA = "DennisRemuxPlayer/1.0"
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            // Addic7ed uses English short language names on its site;
            // map ISO 639-1 to their internal names for best results.
            val addicLang = mapLanguage(languageCode)

            val url = "$SEARCH?search=" + URLEncoder.encode(query, "UTF-8") +
                    "&Submit=Search"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Referer", "https://www.addic7ed.com/")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val html = response.body?.string() ?: return@withContext emptyList()
                    parseHtml(html, addicLang, query)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun parseHtml(html: String, language: String, query: String): List<SubtitleResult> {
        // Addic7ed serves HTML; we scrape the subtitle rows from the results table.
        val results = mutableListOf<SubtitleResult>()
        val rowRegex = Regex(
            """<a[^>]*href="(/original/[^"]+)"[^>]*>([^<]+)</a>""",
            RegexOption.IGNORE_CASE
        )
        val matches = rowRegex.findAll(html)
        for (match in matches.take(20)) {
            val downloadPath = match.groupValues[1]
            val title = match.groupValues[2].trim()
            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = language,
                    releaseTitle = "$title (Addic7ed)",
                    format = "SRT",
                    downloadUrl = "https://www.addic7ed.com$downloadPath",
                    quality = ""
                )
            )
        }
        return results
    }

    private fun mapLanguage(iso: String): String = when (iso.lowercase()) {
        "nl" -> "Dutch"
        "en" -> "English"
        "fr" -> "French"
        "de" -> "German"
        "es" -> "Spanish"
        "it" -> "Italian"
        "cs" -> "Czech"
        "da" -> "Danish"
        "pl" -> "Polish"
        "pt" -> "Portuguese"
        "ru" -> "Russian"
        "sv" -> "Swedish"
        "tr" -> "Turkish"
        else -> iso.uppercase()
    }
}
