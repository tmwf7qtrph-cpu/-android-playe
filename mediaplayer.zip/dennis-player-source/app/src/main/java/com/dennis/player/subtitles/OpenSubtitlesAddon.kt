package com.dennis.player.subtitles

import com.dennis.player.settings.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Real integration with the OpenSubtitles REST API (api.opensubtitles.com).
 *
 * Requires a free developer API key from https://www.opensubtitles.com/en/consumers,
 * stored via PlayerPreferences.openSubtitlesApiKey (settable in Settings > Subtitles >
 * Provider API Keys). Without a key, search() returns an empty list rather than
 * fabricating results — the calling UI shows "No results" in that case, exactly like
 * a real empty search rather than fake data.
 */
class OpenSubtitlesAddon(
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override val id: String = "opensubtitles"
    override val label: String = "OpenSubtitles"

    override val isConfigured: Boolean
        get() = PlayerPreferences.openSubtitlesApiKey.isNotBlank()

    override val configurationHint: String
        get() = "Voer je OpenSubtitles API-sleutel in bij Instellingen"

    companion object {
        private const val BASE_URL = "https://api.opensubtitles.com/api/v1/subtitles"
        private const val USER_AGENT = "DennisRemuxPlayer v1.0.0"
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            val apiKey = PlayerPreferences.openSubtitlesApiKey
            if (apiKey.isBlank()) return@withContext emptyList()

            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val url = buildString {
                append(BASE_URL)
                append("?query=").append(encodedQuery)
                append("&languages=").append(URLEncoder.encode(languageCode, "UTF-8"))
                if (!imdbId.isNullOrBlank()) {
                    append("&imdb_id=").append(URLEncoder.encode(imdbId, "UTF-8"))
                }
            }

            val request = Request.Builder()
                .url(url)
                .header("Api-Key", apiKey)
                .header("User-Agent", USER_AGENT)
                .header("Content-Type", "application/json")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val body = response.body?.string() ?: return@withContext emptyList()
                    parseResults(body)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun parseResults(body: String): List<SubtitleResult> {
        val root = JSONObject(body)
        val data = root.optJSONArray("data") ?: return emptyList()
        val results = mutableListOf<SubtitleResult>()

        for (i in 0 until data.length()) {
            val entry = data.getJSONObject(i)
            val attributes = entry.optJSONObject("attributes") ?: continue
            val files = attributes.optJSONArray("files") ?: continue
            if (files.length() == 0) continue

            val fileId = files.getJSONObject(0).optInt("file_id", -1)
            if (fileId == -1) continue

            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = attributes.optString("language", "?"),
                    releaseTitle = attributes.optString("release", attributes.optString("feature_details", "Unknown release")),
                    format = attributes.optString("format", "srt").uppercase(),
                    // Download URLs from OpenSubtitles require a second call to
                    // /download with this file_id — encoded here so
                    // SubtitleManager.download() can resolve it in one step.
                    downloadUrl = "opensubtitles-file-id://$fileId",
                    isForced = attributes.optBoolean("foreign_parts_only", false),
                    isHearingImpaired = attributes.optBoolean("hearing_impaired", false)
                )
            )
        }
        return results
    }

    /**
     * OpenSubtitles requires a POST to /download with the file_id to obtain a
     * short-lived, per-account download link. Called by SubtitleManager when
     * the user picks a result whose downloadUrl starts with "opensubtitles-file-id://".
     */
    suspend fun resolveDownloadUrl(fileId: Int): String? = withContext(Dispatchers.IO) {
        val apiKey = PlayerPreferences.openSubtitlesApiKey
        if (apiKey.isBlank()) return@withContext null

        val body = okhttp3.RequestBody.create(
            "application/json".toMediaTypeOrNull(),
            JSONObject().put("file_id", fileId).toString()
        )
        val request = Request.Builder()
            .url("https://api.opensubtitles.com/api/v1/download")
            .header("Api-Key", apiKey)
            .header("User-Agent", USER_AGENT)
            .header("Content-Type", "application/json")
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val json = JSONObject(response.body?.string() ?: return@withContext null)
                json.optString("link").ifBlank { null }
            }
        } catch (_: Exception) {
            null
        }
    }
}

private fun String.toMediaTypeOrNull() = okhttp3.MediaType.parse(this)
