package com.dennis.player.player

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.dennis.player.R
import com.dennis.player.audio.AudioTrackHelper
import com.dennis.player.playback.BookmarkManager
import com.dennis.player.playback.PlaylistManager
import com.dennis.player.playback.ResumeStore
import com.dennis.player.settings.PlayerPreferences
import com.dennis.player.subtitles.SubtitleAddonPickerActivity
import com.dennis.player.video.VideoZoomMode
import kotlinx.coroutines.launch

/**
 * Core playback screen built on Media3 ExoPlayer.
 *
 * Responsibilities:
 *  - Builds the player with hardware-decoding-first renderer selection and an
 *    automatic software fallback when a hardware codec fails
 *    (extensionRendererMode = PREFER, onPlayerError fallback below).
 *  - Applies tunneled playback when enabled in Settings, with an automatic
 *    kill-switch that disables it for the rest of the session if playback
 *    errors occur while it is on (see disableTunnelingAfterFailure()).
 *  - Applies the selected VideoZoomMode to the PlayerView's AspectRatioFrameLayout.
 *  - Restores the saved resume position and persists it on pause/stop.
 *  - Advances to the next PlaylistManager entry on playback completion.
 *  - Launches the CC subtitle flow (addon picker -> results -> download -> attach).
 */
@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var resumeStore: ResumeStore
    private lateinit var bookmarkManager: BookmarkManager
    private lateinit var playlistManager: PlaylistManager

    private var currentMediaUri: String? = null
    private var currentMediaTitle: String? = null
    private var currentImdbId: String? = null
    private var tunnelingActiveThisSession = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        resumeStore = ResumeStore(this)
        bookmarkManager = BookmarkManager(this)
        playlistManager = PlaylistManager(this)

        player = buildPlayer()
        playerView.player = player
        applyZoomMode(PlayerPreferences.zoomMode)

        findViewById<android.widget.ImageButton>(R.id.buttonZoom).setOnClickListener {
            val next = PlayerPreferences.zoomMode.next()
            PlayerPreferences.zoomMode = next
            applyZoomMode(next)
        }

        findViewById<android.widget.ImageButton>(R.id.buttonSubtitles).setOnClickListener {
            startActivityForResult(
                Intent(this, SubtitleAddonPickerActivity::class.java).apply {
                    putExtra(SubtitleAddonPickerActivity.EXTRA_MEDIA_TITLE, currentMediaTitle ?: "")
                    putExtra(SubtitleAddonPickerActivity.EXTRA_IMDB_ID, currentImdbId)
                },
                REQUEST_SUBTITLE_FLOW
            )
        }

        findViewById<android.widget.ImageButton>(R.id.buttonAudioTrack).setOnClickListener {
            cycleAudioTrack()
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        // Stremio sends ACTION_VIEW with extras; refresh subtitle metadata
        currentMediaTitle = intent.getStringExtra("title") ?: currentMediaTitle
        currentImdbId = intent.getStringExtra("imdbId") ?: currentImdbId
    }

    private fun handleIntent(intent: Intent) {
        val uri: Uri = intent.data ?: return
        currentMediaUri = uri.toString()
        currentMediaTitle = intent.getStringExtra("title")
            ?: uri.lastPathSegment
            ?: "Unknown"
        currentImdbId = intent.getStringExtra("imdbId")

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .build()

        player.setMediaItem(mediaItem, resumeStore.getPosition(uri.toString()))
        player.playWhenReady = PlayerPreferences.autoPlayEnabled
        player.prepare()

        applyPreferredAudioLanguage()
    }

    private fun buildPlayer(): ExoPlayer {
        val renderersFactory = DefaultRenderersFactory(this).apply {
            // PREFER: try hardware decoders first; ExoPlayer automatically falls
            // back to a software decoder if the hardware decoder fails to
            // initialize or decode, satisfying the "no crashes, auto fallback" requirement.
            setExtensionRendererMode(
                if (PlayerPreferences.hardwareDecodingEnabled) {
                    DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                } else {
                    DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
                }
            )
            setEnableDecoderFallback(true)
        }

        val exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setTunnelingEnabled(PlayerPreferences.tunneledPlaybackEnabled)
            .build()

        tunnelingActiveThisSession = PlayerPreferences.tunneledPlaybackEnabled

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (tunnelingActiveThisSession) {
                    disableTunnelingAfterFailure()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    advanceToNextInPlaylist()
                }
            }
        })

        return exoPlayer
    }

    /** Automatic kill-switch: if tunneled playback causes an error, disable it for future sessions. */
    private fun disableTunnelingAfterFailure() {
        PlayerPreferences.tunneledPlaybackEnabled = false
        tunnelingActiveThisSession = false
    }

    private fun applyZoomMode(mode: VideoZoomMode) {
        playerView.resizeMode = mode.toResizeMode()
        if (mode == VideoZoomMode.ORIGINAL) {
            playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
        }
    }

    private fun applyPreferredAudioLanguage() {
        val params = player.trackSelectionParameters
            .buildUpon()
            .setPreferredAudioLanguage(PlayerPreferences.preferredAudioLanguage)
            .build()
        player.trackSelectionParameters = params
    }

    private fun cycleAudioTrack() {
        val tracks = AudioTrackHelper.listAudioTracks(player)
        if (tracks.isEmpty()) return
        val currentIndex = tracks.indexOfFirst { it.isSelected }
        val next = tracks[(currentIndex + 1) % tracks.size]

        val override = TrackSelectionParameters.Builder(this)
            .setOverrideForType(
                androidx.media3.common.TrackSelectionOverride(
                    player.currentTracks.groups[next.groupIndex].mediaTrackGroup,
                    next.trackIndex
                )
            )
            .build()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .addOverride(override.overrides.values.first())
            .build()
    }

    /** Attaches a downloaded subtitle file as an external text track and re-prepares playback. */
    fun attachExternalSubtitle(fileUri: Uri, languageCode: String) {
        val currentUri = currentMediaUri ?: return
        val position = player.currentPosition

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(fileUri)
            .setMimeType(mimeTypeForSubtitle(fileUri.toString()))
            .setLanguage(languageCode)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(currentUri))
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        player.setMediaItem(mediaItem, position)
        player.prepare()
        player.play()
    }

    private fun mimeTypeForSubtitle(path: String): String = when {
        path.endsWith(".vtt", true) -> androidx.media3.common.MimeTypes.TEXT_VTT
        path.endsWith(".ssa", true) || path.endsWith(".ass", true) -> androidx.media3.common.MimeTypes.TEXT_SSA
        path.endsWith(".sup", true) -> androidx.media3.common.MimeTypes.APPLICATION_PGS
        else -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
    }

    private fun advanceToNextInPlaylist() {
        val currentUri = currentMediaUri ?: return
        val next = playlistManager.nextAfter(currentUri) ?: return
        handleIntent(Intent(Intent.ACTION_VIEW, Uri.parse(next)))
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val stepMs = PlayerPreferences.seekStepSeconds * 1000L
        return when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                player.seekTo(player.currentPosition + stepMs)
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DPAD_LEFT -> {
                player.seekTo((player.currentPosition - stepMs).coerceAtLeast(0))
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onPause() {
        super.onPause()
        currentMediaUri?.let { resumeStore.savePosition(it, player.currentPosition, player.duration.coerceAtLeast(0)) }
        player.pause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SUBTITLE_FLOW && resultCode == RESULT_OK && data != null) {
            val subtitleUri: Uri = data.getParcelableExtra(EXTRA_SUBTITLE_URI) ?: return
            val language = data.getStringExtra(EXTRA_SUBTITLE_LANGUAGE) ?: "und"
            attachExternalSubtitle(subtitleUri, language)
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    companion object {
        const val REQUEST_SUBTITLE_FLOW = 2001
        const val EXTRA_SUBTITLE_URI = "extra_subtitle_uri"
        const val EXTRA_SUBTITLE_LANGUAGE = "extra_subtitle_language"
    }
}
