package com.dennis.player.video

import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout

/**
 * Video scaling modes exposed in Settings and the in-player zoom cycle button.
 * Maps directly onto Media3's AspectRatioFrameLayout resize modes, plus a
 * "Smart Zoom" mode that crops letterbox bars while preserving aspect ratio
 * (implemented as ZOOM in Media3 terms, applied automatically when the source
 * is detected as letterboxed — see PlayerActivity.applySmartZoomIfNeeded).
 */
enum class VideoZoomMode(val key: String, val label: String) {
    FIT("fit", "Fit"),
    FILL("fill", "Fill"),
    STRETCH("stretch", "Stretch"),
    ORIGINAL("original", "Original"),
    ZOOM("zoom", "Zoom"),
    SMART_ZOOM("smart_zoom", "Smart Zoom");

    @UnstableApi
    fun toResizeMode(): Int = when (this) {
        FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        ORIGINAL -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
        ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        SMART_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    }

    fun next(): VideoZoomMode {
        val values = entries.toTypedArray()
        return values[(ordinal + 1) % values.size]
    }

    companion object {
        fun fromKey(key: String?): VideoZoomMode = entries.firstOrNull { it.key == key } ?: FIT
    }
}
