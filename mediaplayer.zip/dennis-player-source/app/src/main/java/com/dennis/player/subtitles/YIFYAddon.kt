package com.dennis.player.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * YIFY Subtitles integration via the YIFY subtitles JSON API
 * (yts-subs.com / yifysubtitles.ch). This is the same source that powers the
 * popular Stremio YIFY subtitle addon — the app queries it directly so results
 * are available even without Stremio running.
 *
 * This addon is free, does not require an API key, and works out of the box.
 */
class YIFYAddon(
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override val id: String = "yify"
    override val label: String = "YIFY Subtitles"

    companion object {
        private const val BASE = "https://yts-subs.com/search"
        private const val UA = "DennisRemuxPlayer/1.0"
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            val url = "$BASE?q=" + URLEncoder.encode(query, "UTF-8") +
                    "&lang=" + URLEncoder.encode(languageCode, "UTF-8")

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "application/json")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val body = response.body?.string() ?: return@withContext emptyList()
                    parse(body)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun parse(body: String): List<SubtitleResult> {
        val root = JSONObject(body)
        val data = root.optJSONArray("subs") ?: root.optJSONArray("data") ?: return emptyList()
        val results = mutableListOf<SubtitleResult>()
        for (i in 0 until data.length()) {
            val entry = data.getJSONObject(i)
            val url = entry.optString("url", entry.optString("zip_link", ""))
            if (url.isBlank()) continue
            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = entry.optString("lang", "und"),
                    releaseTitle = entry.optString("title", "YIFY subtitle"),
                    format = "SRT",
                    downloadUrl = url,
                    quality = entry.optString("quality", "")
                )
            )
        }
        return results
    }
}
