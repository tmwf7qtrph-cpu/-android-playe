package com.dennis.player.subtitles

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dennis.player.R
import com.dennis.player.settings.PlayerPreferences

/**
 * First screen of the CC flow: language selector followed by every registered
 * subtitle addon as a checkbox row, matching the reference screenshots
 * (Uitgeschakeld / Nederlands / ... language list, addon rows with labels,
 * badges, and optional "configure" hints for unconfigured addons).
 * Selecting one or more addons and confirming opens
 * SubtitleResultsActivity with a fanned-out multi-addon search.
 */
class SubtitleAddonPickerActivity : AppCompatActivity() {

    private val languages = listOf(
        "off" to "Uitgeschakeld",
        "nl" to "Nederlands",
        "cs" to "Cze",
        "da" to "Dansk",
        "de" to "Deutsch",
        "en" to "English",
        "fr" to "Fran\u00e7ais",
        "es" to "Espa\u00f1ol"
    )

    private var selectedLanguage: String = PlayerPreferences.preferredSubtitleLanguage
    private val selectedAddonIds = PlayerPreferences.enabledSubtitleAddons.toMutableSet()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subtitle_addon_picker)

        val languageList = findViewById<RecyclerView>(R.id.recyclerLanguages)
        languageList.layoutManager = LinearLayoutManager(this)
        languageList.adapter = LanguageAdapter(languages, selectedLanguage) { code ->
            selectedLanguage = code
        }

        val addonList = findViewById<RecyclerView>(R.id.recyclerAddons)
        addonList.layoutManager = LinearLayoutManager(this)
        addonList.adapter = AddonAdapter(
            SubtitleAddonRegistry.all,
            selectedAddonIds
        ) { id, checked ->
            if (checked) selectedAddonIds.add(id) else selectedAddonIds.remove(id)
        }

        findViewById<android.widget.Button>(R.id.buttonSearch).setOnClickListener {
            PlayerPreferences.preferredSubtitleLanguage = selectedLanguage
            PlayerPreferences.enabledSubtitleAddons = selectedAddonIds

            if (selectedLanguage == "off" || selectedAddonIds.isEmpty()) {
                finish()
                return@setOnClickListener
            }

            val mediaTitle = intent.getStringExtra(EXTRA_MEDIA_TITLE).orEmpty()
            val imdbId = intent.getStringExtra(EXTRA_IMDB_ID)
            startActivityForResult(
                Intent(this, SubtitleResultsActivity::class.java).apply {
                    putExtra(SubtitleResultsActivity.EXTRA_QUERY, mediaTitle)
                    putExtra(SubtitleResultsActivity.EXTRA_LANGUAGE, selectedLanguage)
                    putExtra(SubtitleResultsActivity.EXTRA_IMDB_ID, imdbId)
                    putStringArrayListExtra(SubtitleResultsActivity.EXTRA_ADDON_IDS, ArrayList(selectedAddonIds))
                },
                REQUEST_RESULTS
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_RESULTS) {
            setResult(resultCode, data)
            finish()
        }
    }

    companion object {
        const val EXTRA_MEDIA_TITLE = "extra_media_title"
        const val EXTRA_IMDB_ID = "extra_imdb_id"
        private const val REQUEST_RESULTS = 3001
    }
}

private class LanguageAdapter(
    private val items: List<Pair<String, String>>,
    private var selected: String,
    private val onSelected: (String) -> Unit
) : RecyclerView.Adapter<LanguageAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val text: android.widget.TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_checked, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (code, label) = items[position]
        holder.text.text = label
        holder.itemView.isSelected = code == selected
        holder.itemView.setOnClickListener {
            selected = code
            onSelected(code)
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int = items.size
}

private class AddonAdapter(
    private val addons: List<SubtitleAddon>,
    private val selectedIds: MutableSet<String>,
    private val onToggle: (String, Boolean) -> Unit
) : RecyclerView.Adapter<AddonAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val container: android.widget.LinearLayout = view.findViewById(R.id.addonItemContainer)
        val checkBox: android.widget.CheckBox = view.findViewById(R.id.addonCheckBox)
        val label: android.widget.TextView = view.findViewById(R.id.addonLabel)
        val badge: android.widget.TextView = view.findViewById(R.id.addonBadge)
        val hint: android.widget.TextView = view.findViewById(R.id.addonHint)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subtitle_addon, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val addon = addons[position]
        holder.label.text = addon.label
        holder.checkBox.isChecked = selectedIds.contains(addon.id)

        if (!addon.isConfigured) {
            holder.badge.text = "Configureer"
            holder.badge.setTextColor(android.graphics.Color.parseColor("#FF5C5C"))
            holder.hint.text = addon.configurationHint
            holder.hint.visibility = android.view.View.VISIBLE
            holder.checkBox.isEnabled = false
            holder.container.alpha = 0.5f
        } else {
            holder.badge.text = "Actief"
            holder.badge.setTextColor(android.graphics.Color.parseColor("#3AA6FF"))
            holder.hint.visibility = android.view.View.GONE
            holder.checkBox.isEnabled = true
            holder.container.alpha = 1.0f
        }

        holder.checkBox.setOnCheckedChangeListener { _, checked ->
            if (addon.isConfigured) onToggle(addon.id, checked)
        }
    }

    override fun getItemCount(): Int = addons.size
}
