package com.dennis.player.subtitles

/**
 * A single subtitle search result returned by an addon, before download.
 */
data class SubtitleResult(
    val addonId: String,
    val addonLabel: String,
    val language: String,
    val releaseTitle: String,
    val format: String,
    val downloadUrl: String,
    val quality: String = "",
    val isForced: Boolean = false,
    val isHearingImpaired: Boolean = false
)

/**
 * Contract every subtitle provider must implement. New providers (SubDL,
 * Addic7ed, Podnapisi, YIFY subs, Stremio protocol addons, etc.) are added by
 * implementing this interface and registering the instance in
 * SubtitleAddonRegistry — nothing else in the app needs to change.
 */
interface SubtitleAddon {
    val id: String
    val label: String

    /**
     * Whether this addon is currently functional (has valid credentials / is
     * reachable). When false the picker greys it out and shows a “configure” hint.
     */
    val isConfigured: Boolean
        get() = true

    /**
     * Human-readable configuration hint shown when [isConfigured] == false.
     */
    val configurationHint: String
        get() = ""

    /**
     * Searches for subtitles matching [query] (release/file name, without
     * extension) in the given [languageCode] (ISO 639-1, e.g. "nl", "en").
     * Implementations must be safe to call off the main thread and must not
     * throw on network failure — return an empty list instead.
     *
     * [imdbId] is optional; when supplied providers that support IMDB-id
     * lookups should prefer that over fuzzy text search for better accuracy.
     */
    suspend fun search(query: String, languageCode: String, imdbId: String? = null): List<SubtitleResult>
}
