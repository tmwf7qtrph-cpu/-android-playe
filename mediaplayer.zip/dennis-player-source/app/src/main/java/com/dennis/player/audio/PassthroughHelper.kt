package com.dennis.player.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

data class PassthroughCapability(
    val ac3: Boolean,
    val eac3: Boolean,
    val dtsHd: Boolean,
    val trueHd: Boolean,
    val atmosEac3JocDetected: Boolean
)

/**
 * Detects real bitstream passthrough support on the connected HDMI sink
 * (TV/AVR/receiver) via AudioManager's device capability report, so the
 * player only advertises passthrough for formats the connected hardware can
 * actually decode.
 */
object PassthroughHelper {

    fun detectCapability(context: Context): PassthroughCapability {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        val hdmiDevice = outputDevices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_HDMI || it.type == AudioDeviceInfo.TYPE_HDMI_ARC
        }

        val encodings = hdmiDevice?.encodings?.toSet() ?: emptySet()

        return PassthroughCapability(
            ac3 = android.media.AudioFormat.ENCODING_AC3 in encodings,
            eac3 = android.media.AudioFormat.ENCODING_E_AC3 in encodings,
            dtsHd = encodings.any { it == android.media.AudioFormat.ENCODING_DTS_HD },
            trueHd = encodings.any { it == android.media.AudioFormat.ENCODING_DOLBY_TRUEHD },
            atmosEac3JocDetected = android.media.AudioFormat.ENCODING_E_AC3_JOC in encodings
        )
    }
}
