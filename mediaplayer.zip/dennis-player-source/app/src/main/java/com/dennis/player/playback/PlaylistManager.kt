package com.dennis.player.playback

import android.content.Context
import androidx.core.content.edit
import org.json.JSONArray

/**
 * Ordered list of media URIs queued for continuous playback, with shuffle and
 * repeat modes. PlayerActivity reads this to decide what plays next when the
 * current item ends.
 */
class PlaylistManager(context: Context) {

    enum class RepeatMode { OFF, ONE, ALL }

    private val prefs = context.applicationContext.getSharedPreferences("dennis_playlist", Context.MODE_PRIVATE)

    var shuffleEnabled: Boolean
        get() = prefs.getBoolean("shuffle_enabled", false)
        set(value) = prefs.edit { putBoolean("shuffle_enabled", value) }

    var repeatMode: RepeatMode
        get() = RepeatMode.valueOf(prefs.getString("repeat_mode", RepeatMode.OFF.name) ?: RepeatMode.OFF.name)
        set(value) = prefs.edit { putString("repeat_mode", value.name) }

    fun setQueue(items: List<String>) {
        val array = JSONArray()
        items.forEach { array.put(it) }
        prefs.edit { putString("queue", array.toString()) }
    }

    fun getQueue(): List<String> {
        val raw = prefs.getString("queue", null) ?: return emptyList()
        val array = JSONArray(raw)
        return (0 until array.length()).map { array.getString(it) }
    }

    /**
     * Given the currently playing URI, returns the next URI to play according
     * to shuffle/repeat settings, or null if the queue has ended.
     */
    fun nextAfter(currentUri: String): String? {
        val queue = getQueue()
        if (queue.isEmpty()) return null

        if (repeatMode == RepeatMode.ONE) return currentUri

        val currentIndex = queue.indexOf(currentUri)
        if (shuffleEnabled) {
            val remaining = queue.filterIndexed { index, _ -> index != currentIndex }
            return remaining.randomOrNull() ?: if (repeatMode == RepeatMode.ALL) queue.random() else null
        }

        val nextIndex = currentIndex + 1
        return when {
            nextIndex < queue.size -> queue[nextIndex]
            repeatMode == RepeatMode.ALL -> queue.firstOrNull()
            else -> null
        }
    }
}
