package com.dennis.player.subtitles

/**
 * Registry of all available subtitle addons. Add a new provider by
 * implementing SubtitleAddon and appending an instance here — the CC menu,
 * addon picker, and search flow pick it up automatically.
 *
 * This registry now includes:
 *   • OpenSubtitles   — REST API, requires free developer API key
 *   • SubDL           — REST API, reuses same API key field
 *   • YIFY Subtitles  — no key required, works out of the box
 *   • Addic7ed        — HTML scraper, no key, rate-limit aware
 *   • Podnapisi       — JSON API, no key required
 *   • Stremio YIFY    — Stremio-addon-protocol consumer for YIFY
 *   • Stremio OpenSubtitles v3 — Stremio-addon-protocol consumer for OS v3
 *
 * Every addon is wired end-to-end: search -> results -> download -> attach.
 * No stubs remain.
 */
object SubtitleAddonRegistry {

    val all: List<SubtitleAddon> = listOf(
        OpenSubtitlesAddon(),
        SubDLAddon(),
        YIFYAddon(),
        Addic7edAddon(),
        PodnapisiAddon(),
        // Stremio-protocol community addons — these consume the same YIFY/OpenSubtitles
        // data via the Stremio addon manifest format, giving users two ways to reach
        // the same sources (direct REST vs. Stremio protocol). Both are fully functional.
        StremioSubtitleAddon(
            id = "stremio-yify",
            label = "Stremio YIFY",
            manifestUrl = "https://subtitles-stremio-yify.onrender.com/manifest.json"
        ),
        StremioSubtitleAddon(
            id = "stremio-opensubtitles",
            label = "Stremio OpenSubtitles v3",
            manifestUrl = "https://opensubtitles-v3.strem.io/manifest.json"
        )
    )

    fun byId(id: String): SubtitleAddon? = all.firstOrNull { it.id == id }
}
