package com.dennis.player.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Generic Stremio-addon-protocol subtitle provider.
 *
 * Stremio subtitle addons expose a manifest.json and a
 *   /subtitles/{type}/{id}.json
 * endpoint that returns a list of subtitle objects with `url`, `lang` and
 * optional `title`. This class lets the player treat any Stremio-compatible
 * subtitle addon as a first-class [SubtitleAddon] — community addons such as
 * YIFY subs, OpenSubtitles (v3), SubDL, etc. can all be consumed without
 * custom code per provider.
 *
 * Pre-configured URLs for well-known community addons are added in
 * SubtitleAddonRegistry.
 */
class StremioSubtitleAddon(
    override val id: String,
    override val label: String,
    private val manifestUrl: String,
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override var isConfigured: Boolean = true
        private set

    override val configurationHint: String
        get() = "Controleer internetverbinding of addon-URL"

    private var subtitlesPathTemplate: String = "/subtitles/{type}/{id}"

    init {
        // Attempt to fetch manifest on first use so we know the exact endpoint.
        // We do not block init; the first search() call will lazy-resolve.
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            resolveManifestIfNeeded()

            val actualId = imdbId ?: guessImdbFromQuery(query)
            if (actualId == null) {
                // Fallback: some Stremio subtitle addons accept a plain query via
                // a "subtitles" resource with an extra "search" parameter, but most
                // require a catalogue meta id. Without an id we cannot call them.
                return@withContext emptyList()
            }

            val endpoint = subtitlesPathTemplate
                .replace("{type}", "movie")
                .replace("{id}", actualId)

            val url = ensureTrailingSlash(manifestUrl.substringBefore("/manifest.json")) +
                    endpoint.removePrefix("/") +
                    ".json?lang=" + URLEncoder.encode(languageCode, "UTF-8")

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "DennisRemuxPlayer/1.0")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val body = response.body?.string() ?: return@withContext emptyList()
                    parseStremioResponse(body)
                }
            } catch (_: Exception) {
                isConfigured = false
                emptyList()
            }
        }

    private fun parseStremioResponse(body: String): List<SubtitleResult> {
        val root = JSONObject(body)
        val subs = root.optJSONArray("subtitles") ?: return emptyList()
        val results = mutableListOf<SubtitleResult>()
        for (i in 0 until subs.length()) {
            val entry = subs.getJSONObject(i)
            val lang = entry.optString("lang", "und")
            val url = entry.optString("url", "")
            if (url.isBlank()) continue
            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = lang,
                    releaseTitle = entry.optString("title", "$label subtitle"),
                    format = url.substringAfterLast(".", "srt").uppercase(),
                    downloadUrl = url,
                    isForced = entry.optBoolean("forced", false)
                )
            )
        }
        return results
    }

    private fun resolveManifestIfNeeded() {
        if (subtitlesPathTemplate != "/subtitles/{type}/{id}") return // already resolved
        try {
            val manifestReq = Request.Builder()
                .url(manifestUrl)
                .header("User-Agent", "DennisRemuxPlayer/1.0")
                .get()
                .build()
            client.newCall(manifestReq).execute().use { response ->
                if (!response.isSuccessful) {
                    isConfigured = false
                    return
                }
                val json = JSONObject(response.body?.string() ?: return)
                val resources = json.optJSONArray("resources")
                if (resources != null) {
                    for (i in 0 until resources.length()) {
                        val res = resources.getJSONObject(i)
                        val name = res.optString("name", "")
                        if (name.equals("subtitles", ignoreCase = true)) {
                            val paths = res.optJSONObject("typesPaths")
                            if (paths != null) {
                                val keys = paths.keys()
                                while (keys.hasNext()) {
                                    val key = keys.next()
                                    val path = paths.optString(key, "")
                                    if (path.isNotBlank()) {
                                        subtitlesPathTemplate = path
                                        return
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
            isConfigured = false
        }
    }

    private fun guessImdbFromQuery(query: String): String? {
        // Many Stremio addons expect an IMDB id (tt1234567).
        // If the query already contains "tt" followed by digits, extract it.
        val regex = Regex("""tt\d+""")
        return regex.find(query)?.value
    }

    private fun ensureTrailingSlash(url: String): String =
        if (url.endsWith("/")) url else "$url/"
}
