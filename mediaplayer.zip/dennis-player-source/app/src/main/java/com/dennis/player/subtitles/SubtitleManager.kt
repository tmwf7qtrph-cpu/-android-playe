package com.dennis.player.subtitles

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

/**
 * Orchestrates the Stremio-style subtitle flow:
 *   1. searchAcrossAddons() fans out the query to every enabled addon in
 *      parallel and merges the results (mirrors the CC menu -> addon list ->
 *      results screen flow).
 *   2. download() fetches the chosen result to local storage.
 *   3. PlayerActivity attaches the resulting file as an external subtitle
 *      track and starts playback automatically.
 */
class SubtitleManager(
    private val context: Context,
    private val client: OkHttpClient = OkHttpClient()
) {

    suspend fun searchAcrossAddons(
        addonIds: Set<String>,
        query: String,
        languageCode: String,
        imdbId: String? = null
    ): List<SubtitleResult> = coroutineScope {
        addonIds
            .mapNotNull { SubtitleAddonRegistry.byId(it) }
            .filter { it.isConfigured }
            .map { addon -> async { runCatching { addon.search(query, languageCode, imdbId) }.getOrDefault(emptyList()) } }
            .awaitAll()
            .flatten()
            .sortedBy { it.releaseTitle }
    }

    /**
     * Downloads [result] to app-private storage and returns the local file,
     * or null if the download failed (e.g. missing API key, network error).
     * Handles the OpenSubtitles two-step resolve+download flow transparently.
     */
    suspend fun download(result: SubtitleResult): File? = withContext(Dispatchers.IO) {
        val resolvedUrl = resolveUrl(result) ?: return@withContext null

        val request = Request.Builder().url(resolvedUrl).get().build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val bytes = response.body?.bytes() ?: return@withContext null

                val extension = result.format.lowercase().ifBlank { "srt" }
                val outFile = File(subtitleCacheDir(), "${sanitize(result.releaseTitle)}.$extension")
                FileOutputStream(outFile).use { it.write(bytes) }
                outFile
            }
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun resolveUrl(result: SubtitleResult): String? {
        if (result.downloadUrl.startsWith("opensubtitles-file-id://")) {
            val fileId = result.downloadUrl.removePrefix("opensubtitles-file-id://").toIntOrNull()
                ?: return null
            val addon = SubtitleAddonRegistry.byId("opensubtitles") as? OpenSubtitlesAddon ?: return null
            return addon.resolveDownloadUrl(fileId)
        }
        return result.downloadUrl
    }

    private fun subtitleCacheDir(): File =
        File(context.cacheDir, "subtitles").apply { mkdirs() }

    private fun sanitize(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
}
