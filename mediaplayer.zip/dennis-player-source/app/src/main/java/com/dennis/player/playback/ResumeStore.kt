package com.dennis.player.playback

import android.content.Context
import androidx.core.content.edit

/**
 * Persists last-known playback position per media URI so playback can resume
 * where the user left off, mirroring the "Resume" feature from the spec.
 */
class ResumeStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("dennis_resume_store", Context.MODE_PRIVATE)

    fun savePosition(mediaUri: String, positionMs: Long, durationMs: Long) {
        // Do not persist a resume point once the user has watched past 95% —
        // treat it as finished so the next open starts from zero.
        if (durationMs > 0 && positionMs >= durationMs * 95 / 100) {
            clear(mediaUri)
            return
        }
        prefs.edit { putLong(keyFor(mediaUri), positionMs) }
    }

    fun getPosition(mediaUri: String): Long = prefs.getLong(keyFor(mediaUri), 0L)

    fun clear(mediaUri: String) {
        prefs.edit { remove(keyFor(mediaUri)) }
    }

    private fun keyFor(mediaUri: String): String = "resume_${mediaUri.hashCode()}"
}
