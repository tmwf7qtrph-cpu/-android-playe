package com.dennis.player.video

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil

enum class DynamicRangeType { SDR, HDR10, HDR10_PLUS, DOLBY_VISION, HLG, UNKNOWN }

/**
 * Reports what dynamic range the connected display actually supports, using
 * Display.HdrCapabilities (API 24+) — used to decide whether to tone-map
 * Dolby Vision/HDR10+ down to HDR10/SDR instead of feeding an unsupported
 * signal to the display, and to show an accurate "HDR: Dolby Vision" badge
 * in the player UI rather than assuming support.
 */
object HdrHelper {

    fun getDisplaySupportedRanges(context: Context): Set<DynamicRangeType> {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY) ?: return setOf(DynamicRangeType.SDR)

        val hdrCapabilities = display.hdrCapabilities ?: return setOf(DynamicRangeType.SDR)
        val types = hdrCapabilities.supportedHdrTypes.toSet()

        val result = mutableSetOf(DynamicRangeType.SDR)
        if (Display.HdrCapabilities.HDR_TYPE_HDR10 in types) result += DynamicRangeType.HDR10
        if (Build.VERSION.SDK_INT >= 29 && Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS in types) {
            result += DynamicRangeType.HDR10_PLUS
        }
        if (Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION in types) result += DynamicRangeType.DOLBY_VISION
        if (Display.HdrCapabilities.HDR_TYPE_HLG in types) result += DynamicRangeType.HLG
        return result
    }

    /** True if the device exposes at least one hardware decoder for the given [mimeType]. */
    @UnstableApi
    fun hasHardwareDecoderFor(mimeType: String): Boolean =
        runCatching {
            MediaCodecUtil.getDecoderInfos(mimeType, false, false).any { it.hardwareAccelerated }
        }.getOrDefault(false)
}
