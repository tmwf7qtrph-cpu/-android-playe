package com.dennis.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dennis.player.R
import com.dennis.player.playback.PlaylistManager
import com.dennis.player.player.PlayerActivity

/**
 * Shows the current playback queue with shuffle/repeat toggles. Tapping an
 * entry jumps straight to that item in PlayerActivity.
 */
class PlaylistActivity : AppCompatActivity() {

    private lateinit var playlistManager: PlaylistManager
    private lateinit var adapter: QueueAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlist)

        playlistManager = PlaylistManager(this)

        val recycler = findViewById<RecyclerView>(R.id.recyclerQueue)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = QueueAdapter(playlistManager.getQueue()) { uri -> openInPlayer(uri) }
        recycler.adapter = adapter

        val shuffleSwitch = findViewById<android.widget.Switch>(R.id.switchShuffle)
        shuffleSwitch.isChecked = playlistManager.shuffleEnabled
        shuffleSwitch.setOnCheckedChangeListener { _, checked -> playlistManager.shuffleEnabled = checked }

        val repeatSpinner = findViewById<android.widget.Spinner>(R.id.spinnerRepeat)
        val repeatModes = PlaylistManager.RepeatMode.values()
        repeatSpinner.adapter = android.widget.ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            repeatModes.map { it.name }
        )
        repeatSpinner.setSelection(repeatModes.indexOf(playlistManager.repeatMode))
        repeatSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                playlistManager.repeatMode = repeatModes[position]
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
    }

    private fun openInPlayer(uri: String) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = Uri.parse(uri)
        })
    }
}

private class QueueAdapter(
    private val items: List<String>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<QueueAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val text: android.widget.TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val uri = items[position]
        holder.text.text = Uri.parse(uri).lastPathSegment ?: uri
        holder.itemView.setOnClickListener { onClick(uri) }
    }

    override fun getItemCount(): Int = items.size
}
