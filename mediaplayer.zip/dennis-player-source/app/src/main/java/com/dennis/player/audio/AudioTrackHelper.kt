package com.dennis.player.audio

import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

data class AudioTrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val language: String,
    val codec: String,
    val channelCount: Int,
    val label: String,
    val isSelected: Boolean
)

/**
 * Enumerates every audio track embedded in the current source (Dolby Atmos,
 * TrueHD, DTS-HD MA, AAC, FLAC, PCM, etc.) so the player can present a manual
 * switcher and detect the best automatic-language match.
 */
@UnstableApi
object AudioTrackHelper {

    fun listAudioTracks(player: ExoPlayer): List<AudioTrackOption> {
        val options = mutableListOf<AudioTrackOption>()
        val groups = player.currentTracks.groups

        groups.forEachIndexed { groupIndex, group ->
            if (group.type != C.TRACK_TYPE_AUDIO) return@forEachIndexed
            for (trackIndex in 0 until group.length) {
                val format = group.getTrackFormat(trackIndex)
                options.add(
                    AudioTrackOption(
                        groupIndex = groupIndex,
                        trackIndex = trackIndex,
                        language = format.language ?: "und",
                        codec = format.sampleMimeType ?: "unknown",
                        channelCount = format.channelCount,
                        label = buildLabel(format.language, format.sampleMimeType, format.channelCount),
                        isSelected = group.isTrackSelected(trackIndex)
                    )
                )
            }
        }
        return options
    }

    /** Picks the first audio track whose language matches [preferredLanguage], if any. */
    fun findPreferredTrack(tracks: Tracks, preferredLanguage: String): AudioTrackOption? =
        listOfNotNull(
            tracks.groups
                .filter { it.type == C.TRACK_TYPE_AUDIO }
                .flatMapIndexed { groupIndex, group ->
                    (0 until group.length).mapNotNull { trackIndex ->
                        val format = group.getTrackFormat(trackIndex)
                        if (format.language == preferredLanguage) {
                            AudioTrackOption(
                                groupIndex, trackIndex, format.language ?: "und",
                                format.sampleMimeType ?: "unknown", format.channelCount,
                                buildLabel(format.language, format.sampleMimeType, format.channelCount),
                                group.isTrackSelected(trackIndex)
                            )
                        } else null
                    }
                }
                .firstOrNull()
        ).firstOrNull()

    private fun buildLabel(language: String?, mimeType: String?, channels: Int): String {
        val codecName = when {
            mimeType?.contains("ac4") == true -> "Dolby AC-4"
            mimeType?.contains("eac3") == true -> "Dolby Digital Plus"
            mimeType?.contains("ac3") == true -> "Dolby Digital"
            mimeType?.contains("truehd") == true -> "Dolby TrueHD"
            mimeType?.contains("dts") == true -> "DTS-HD"
            mimeType?.contains("flac") == true -> "FLAC"
            mimeType?.contains("raw") == true -> "PCM"
            mimeType?.contains("aac") == true -> "AAC"
            else -> mimeType ?: "Unknown"
        }
        val channelLabel = when (channels) {
            8 -> "7.1"
            6 -> "5.1"
            2 -> "Stereo"
            1 -> "Mono"
            else -> "${channels}ch"
        }
        return "${language ?: "Unknown"} \u00b7 $codecName \u00b7 $channelLabel"
    }
}
