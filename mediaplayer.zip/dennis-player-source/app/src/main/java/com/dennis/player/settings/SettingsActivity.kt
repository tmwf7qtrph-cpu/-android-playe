package com.dennis.player.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dennis.player.R

/**
 * Settings screen matching the reference screenshots: playback (HW decoding,
 * tunneling, auto-play, seek step), audio (preferred language, passthrough),
 * subtitles (language, auto-select Dutch, text size, position, color,
 * outline/shadow, background opacity, bold/italic, sync offset), and the
 * OpenSubtitles API key field. All values persist via PlayerPreferences.
 */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        bindSwitch(R.id.switchHwDecoding, PlayerPreferences.hardwareDecodingEnabled) {
            PlayerPreferences.hardwareDecodingEnabled = it
        }
        bindSwitch(R.id.switchTunneling, PlayerPreferences.tunneledPlaybackEnabled) {
            PlayerPreferences.tunneledPlaybackEnabled = it
        }
        bindSwitch(R.id.switchAutoPlay, PlayerPreferences.autoPlayEnabled) {
            PlayerPreferences.autoPlayEnabled = it
        }
        bindSwitch(R.id.switchAutoDutchSubs, PlayerPreferences.autoSelectDutchSubtitle) {
            PlayerPreferences.autoSelectDutchSubtitle = it
        }
        bindSwitch(R.id.switchSubOutline, PlayerPreferences.subtitleOutlineEnabled) {
            PlayerPreferences.subtitleOutlineEnabled = it
        }
        bindSwitch(R.id.switchSubShadow, PlayerPreferences.subtitleShadowEnabled) {
            PlayerPreferences.subtitleShadowEnabled = it
        }
        bindSwitch(R.id.switchSubBold, PlayerPreferences.subtitleBold) {
            PlayerPreferences.subtitleBold = it
        }
        bindSwitch(R.id.switchSubItalic, PlayerPreferences.subtitleItalic) {
            PlayerPreferences.subtitleItalic = it
        }

        val audioLangField = findViewById<android.widget.EditText>(R.id.editAudioLanguage)
        audioLangField.setText(PlayerPreferences.preferredAudioLanguage)
        audioLangField.doAfterTextChangedCompat { PlayerPreferences.preferredAudioLanguage = it }

        val subLangField = findViewById<android.widget.EditText>(R.id.editSubtitleLanguage)
        subLangField.setText(PlayerPreferences.preferredSubtitleLanguage)
        subLangField.doAfterTextChangedCompat { PlayerPreferences.preferredSubtitleLanguage = it }

        val textSizeSeek = findViewById<android.widget.SeekBar>(R.id.seekSubTextSize)
        textSizeSeek.progress = PlayerPreferences.subtitleTextSizePt
        textSizeSeek.setOnSeekBarChangeListener(simpleSeekListener {
            PlayerPreferences.subtitleTextSizePt = it
        })

        val positionSeek = findViewById<android.widget.SeekBar>(R.id.seekSubPosition)
        positionSeek.progress = PlayerPreferences.subtitlePositionPercent
        positionSeek.setOnSeekBarChangeListener(simpleSeekListener {
            PlayerPreferences.subtitlePositionPercent = it
        })

        val backgroundAlphaSeek = findViewById<android.widget.SeekBar>(R.id.seekSubBackgroundAlpha)
        backgroundAlphaSeek.progress = PlayerPreferences.subtitleBackgroundAlpha
        backgroundAlphaSeek.setOnSeekBarChangeListener(simpleSeekListener {
            PlayerPreferences.subtitleBackgroundAlpha = it
        })

        val apiKeyField = findViewById<android.widget.EditText>(R.id.editOpenSubtitlesKey)
        apiKeyField.setText(PlayerPreferences.openSubtitlesApiKey)
        apiKeyField.doAfterTextChangedCompat { PlayerPreferences.openSubtitlesApiKey = it }
    }

    private fun bindSwitch(id: Int, initial: Boolean, onChange: (Boolean) -> Unit) {
        findViewById<android.widget.Switch>(id).apply {
            isChecked = initial
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
    }

    private fun simpleSeekListener(onChange: (Int) -> Unit) =
        object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        }

    private fun android.widget.EditText.doAfterTextChangedCompat(action: (String) -> Unit) {
        addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { action(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }
}
