package com.dennis.player.playback

import android.content.Context
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val mediaUri: String, val label: String, val positionMs: Long)

/**
 * Named bookmarks within a media file (distinct from the automatic resume
 * position) — e.g. "Intro ends", "Best scene". Stored as a JSON array per
 * media URI so a single title can have several bookmarks.
 */
class BookmarkManager(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("dennis_bookmarks", Context.MODE_PRIVATE)

    fun add(mediaUri: String, label: String, positionMs: Long) {
        val list = getAll(mediaUri).toMutableList()
        list.add(Bookmark(mediaUri, label, positionMs))
        persist(mediaUri, list)
    }

    fun remove(mediaUri: String, positionMs: Long) {
        val list = getAll(mediaUri).filterNot { it.positionMs == positionMs }
        persist(mediaUri, list)
    }

    fun getAll(mediaUri: String): List<Bookmark> {
        val raw = prefs.getString(keyFor(mediaUri), null) ?: return emptyList()
        val array = JSONArray(raw)
        return (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            Bookmark(mediaUri, obj.getString("label"), obj.getLong("positionMs"))
        }
    }

    private fun persist(mediaUri: String, bookmarks: List<Bookmark>) {
        val array = JSONArray()
        bookmarks.forEach {
            array.put(JSONObject().put("label", it.label).put("positionMs", it.positionMs))
        }
        prefs.edit { putString(keyFor(mediaUri), array.toString()) }
    }

    private fun keyFor(mediaUri: String): String = "bookmarks_${mediaUri.hashCode()}"
}
