package com.dennis.player.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Podnapisi.net (subtitle search) integration via their public search API.
 *
 * Podnapisi is a long-standing subtitle archive especially strong for Eastern
 * European languages. Their JSON search endpoint is public and does not require
 * authentication, so this addon works out of the box.
 */
class PodnapisiAddon(
    private val client: OkHttpClient = OkHttpClient()
) : SubtitleAddon {

    override val id: String = "podnapisi"
    override val label: String = "Podnapisi"

    companion object {
        private const val BASE = "https://www.podnapisi.net/subtitles/search/old"
        private const val UA = "DennisRemuxPlayer/1.0"
    }

    override suspend fun search(query: String, languageCode: String, imdbId: String?): List<SubtitleResult> =
        withContext(Dispatchers.IO) {
            val url = "$BASE?keywords=" + URLEncoder.encode(query, "UTF-8") +
                    "&language=" + URLEncoder.encode(mapLanguageCode(languageCode), "UTF-8")

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "application/json")
                .get()
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext emptyList()
                    val body = response.body?.string() ?: return@withContext emptyList()
                    parse(body)
                }
            } catch (_: Exception) {
                emptyList()
            }
        }

    private fun parse(body: String): List<SubtitleResult> {
        val root = JSONObject(body)
        val data = root.optJSONArray("data") ?: return emptyList()
        val results = mutableListOf<SubtitleResult>()
        for (i in 0 until data.length()) {
            val entry = data.getJSONObject(i)
            val dl = entry.optString("url", entry.optString("download", ""))
            if (dl.isBlank()) continue
            results.add(
                SubtitleResult(
                    addonId = id,
                    addonLabel = label,
                    language = entry.optString("language", "und"),
                    releaseTitle = entry.optString("release", entry.optString("title", "Podnapisi subtitle")),
                    format = "SRT",
                    downloadUrl = if (dl.startsWith("http")) dl else "https://www.podnapisi.net$dl",
                    quality = entry.optString("quality", "")
                )
            )
        }
        return results
    }

    private fun mapLanguageCode(iso: String): String = when (iso.lowercase()) {
        "nl" -> "nld"
        "en" -> "eng"
        "fr" -> "fre"
        "de" -> "ger"
        "es" -> "spa"
        "it" -> "ita"
        "cs" -> "cze"
        "da" -> "dan"
        "pl" -> "pol"
        "pt" -> "por"
        "ru" -> "rus"
        "sv" -> "swe"
        "tr" -> "tur"
        else -> iso
    }
}
