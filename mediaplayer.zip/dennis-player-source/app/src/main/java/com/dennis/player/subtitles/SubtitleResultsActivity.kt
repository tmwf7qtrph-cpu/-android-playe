package com.dennis.player.subtitles

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dennis.player.R
import com.dennis.player.player.PlayerActivity
import kotlinx.coroutines.launch

/**
 * Second screen of the CC flow: scrollable, aggregated results from every
 * addon selected on the previous screen (release name, quality, format,
 * forced/HI flags) — mirrors the ExoPlayer-in-Stremio subtitle results list.
 * Selecting a row downloads, attaches, and starts playback automatically —
 * no extra confirmation dialogs, matching the "no extra windows" requirement.
 */
class SubtitleResultsActivity : AppCompatActivity() {

    private lateinit var subtitleManager: SubtitleManager
    private lateinit var recyclerView: RecyclerView
    private lateinit var progress: android.widget.ProgressBar
    private lateinit var emptyView: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subtitle_results)

        subtitleManager = SubtitleManager(this)
        recyclerView = findViewById(R.id.recyclerResults)
        recyclerView.layoutManager = LinearLayoutManager(this)
        progress = findViewById(R.id.progressSearching)
        emptyView = findViewById(R.id.textEmpty)

        val query = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val language = intent.getStringExtra(EXTRA_LANGUAGE).orEmpty()
        val imdbId = intent.getStringExtra(EXTRA_IMDB_ID)
        val addonIds = intent.getStringArrayListExtra(EXTRA_ADDON_IDS)?.toSet().orEmpty()

        runSearch(addonIds, query, language, imdbId)
    }

    private fun runSearch(addonIds: Set<String>, query: String, language: String, imdbId: String?) {
        progress.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            val results = subtitleManager.searchAcrossAddons(addonIds, query, language, imdbId)
            progress.visibility = android.view.View.GONE

            if (results.isEmpty()) {
                emptyView.visibility = android.view.View.VISIBLE
                return@launch
            }

            recyclerView.adapter = ResultsAdapter(results) { selected -> onResultSelected(selected) }
        }
    }

    private fun onResultSelected(result: SubtitleResult) {
        lifecycleScope.launch {
            val file = subtitleManager.download(result)
            if (file == null) {
                Toast.makeText(this@SubtitleResultsActivity, R.string.subtitle_download_failed, Toast.LENGTH_SHORT).show()
                return@launch
            }

            val uri: Uri = FileProvider.getUriForFile(
                this@SubtitleResultsActivity,
                "${packageName}.fileprovider",
                file
            )

            setResult(RESULT_OK, Intent().apply {
                putExtra(PlayerActivity.EXTRA_SUBTITLE_URI, uri)
                putExtra(PlayerActivity.EXTRA_SUBTITLE_LANGUAGE, result.language)
            })
            finish()
        }
    }

    companion object {
        const val EXTRA_QUERY = "extra_query"
        const val EXTRA_LANGUAGE = "extra_language"
        const val EXTRA_IMDB_ID = "extra_imdb_id"
        const val EXTRA_ADDON_IDS = "extra_addon_ids"
    }
}

private class ResultsAdapter(
    private val results: List<SubtitleResult>,
    private val onClick: (SubtitleResult) -> Unit
) : RecyclerView.Adapter<ResultsAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val title: android.widget.TextView = view.findViewById(R.id.textResultTitle)
        val subtitle: android.widget.TextView = view.findViewById(R.id.textResultMeta)
        val badge: android.widget.TextView = view.findViewById(R.id.textResultAddon)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subtitle_result, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val result = results[position]
        holder.title.text = result.releaseTitle
        val flags = buildString {
            if (result.isForced) append("Forced ")
            if (result.isHearingImpaired) append("HI ")
        }
        holder.subtitle.text = "${result.language.uppercase()} \u00b7 ${result.format} $flags".trim()
        holder.badge.text = result.addonLabel
        holder.itemView.setOnClickListener { onClick(result) }
    }

    override fun getItemCount(): Int = results.size
}
