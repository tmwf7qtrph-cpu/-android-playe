@rem Gradle startup script for Windows
@echo off
set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
    echo gradle-wrapper.jar not found. Open this project in Android Studio, or run
    echo 'gradle wrapper' with a locally installed Gradle to regenerate it.
    exit /b 1
)

"%JAVA_HOME%\bin\java.exe" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
