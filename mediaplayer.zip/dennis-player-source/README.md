# Dennis 4K Dolby Vision Remux Player — Android bronbestanden

Dit is een echt, werkend Android Studio-project (Kotlin + AndroidX Media3/ExoPlayer),
gebouwd voor 4K Dolby Vision/HDR remux-afspelen op Android TV boxes (ARM, Android 11+,
SDK 30–34). Alle code in dit project is functioneel — er zit geen placeholder- of
demo-logica in de kernonderdelen (afspelen, zoom, HDR-detectie, audiotracks,
passthrough-detectie, resume/bookmarks/afspeellijst, OpenSubtitles-integratie).

## Openen in Android Studio

1. Open Android Studio (Koala/Ladybug of nieuwer aanbevolen).
2. "Open" → selecteer de map `android-source/`.
3. Android Studio genereert automatisch de ontbrekende `gradle-wrapper.jar` zodra
   je het project synchroniseert (of run zelf `gradle wrapper` als je Gradle al
   lokaal hebt geïnstalleerd). Dat binaire bestand kon niet worden meegeleverd
   in deze broncode-export.
4. Sync Gradle, kies een `debug`-buildvariant, en installeer op je Android TV box
   of emulator (minSdk 30).

## Belangrijke, eerlijke kanttekeningen

Dit project levert een **volwaardige, functionele mediaspeler**, maar een paar
claims uit de oorspronkelijke wensenlijst zijn hier bewust **niet** kunstmatig
nagebootst:

- **APK-grootte van 100MB+**: een gecompileerde Kotlin/Media3-app van deze omvang
  is realistisch **10–25MB**, niet 100MB+. Alleen door willekeurige assets/bloat
  toe te voegen zou je aan 100MB komen — dat is misleidend en is hier niet gedaan.
- **"Beter dan VLC" / officiële certificering**: dit is geen meetbaar, toekenbaar
  keurmerk. De speler is professioneel opgezet (Media3, tunneling, HW-decodering,
  echte passthrough/HDR-detectie), maar een dergelijke claim wordt hier niet als
  code of badge nagebootst.
- **OpenSubtitles-integratie is echt** maar vereist je eigen gratis API-key
  (via opensubtitles.com/consumers) — vul deze in via Instellingen. Zonder key
  geeft de addon een lege resultatenlijst terug (geen nep-resultaten).
- **SubDL / Addic7ed / Podnapisi / YIFY-addons** zijn als eerlijke "stub"-addons
  opgenomen: ze implementeren de volledige `SubtitleAddon`-interface en verschijnen
  in de addon-kiezer, maar geven momenteel een lege lijst terug totdat je hun
  respectievelijke API's aansluit. Dit is bewust zo (geen nep-ondertitels), en
  het toevoegen van een echte integratie is een kwestie van de `search()`-functie
  in te vullen — de rest van de app (download, attach, UI) werkt al voor elke addon.

## Kernfunctionaliteit die wél volledig werkt

- HW-gedecodeerde 4K/HDR/Dolby Vision-afspelen via Media3 `DefaultRenderersFactory`
  met automatische software-fallback bij decoderfouten.
- Tunneled playback met automatische uitschakeling na een afspeelfout
  (kill-switch, voorkomt een kapotte afspeelervaring).
- 6 zoom/aspect-ratio modi (Fit/Fill/Stretch/Original/Zoom/SmartZoom).
- Audiotrack-detectie en -omschakeling (Atmos/TrueHD/DTS-HD/AAC/FLAC/PCM) met
  labels en taalherkenning.
- Echte HDMI-passthrough-capaciteitsdetectie via `AudioManager`/`AudioDeviceInfo`.
- Echte HDR-capaciteitsdetectie via `Display.HdrCapabilities`
  (HDR10/HDR10+/Dolby Vision/HLG).
- Stremio-identieke ondertitelflow: CC-knop → taal + addon-kiezer → verzamelde
  resultatenlijst → download & automatisch aankoppelen, zonder extra dialogen.
- Ondertitel-styling (grootte, positie, kleur, omranding, schaduw, vet/cursief,
  achtergrond-dekking, sync-offset).
- Resume-posities, bookmarks en een afspeellijst met shuffle/repeat.
- Herkenning als Stremio External Player via bijpassende `ACTION_VIEW`
  intent-filters (video/*, http/https/content/file-schema's, .mkv/.mp4 paden).

## Projectstructuur

```
app/src/main/java/com/dennis/player/
  ui/            MainActivity, PlaylistActivity
  player/        PlayerActivity (ExoPlayer-kern)
  settings/      PlayerPreferences, SettingsActivity
  subtitles/     SubtitleAddon(s), SubtitleManager, addon-kiezer & resultaten
  playback/      ResumeStore, BookmarkManager, PlaylistManager
  audio/         AudioTrackHelper, PassthroughHelper
  video/         VideoZoomMode, HdrHelper
```
